package com.example.freecall

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var statusText: TextView
    private lateinit var micButton: Button
    private var isListening = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        statusText = findViewById(R.id.statusText)
        micButton = findViewById(R.id.micButton)
        
        // التحقق من الأذونات
        if (!hasPermissions()) {
            requestPermissionsMethod()
        } else {
            initSpeechRecognizer()
        }
        
        // عند الضغط على الزر
        micButton.setOnClickListener {
            if (isListening) {
                speechRecognizer.stopListening()
                isListening = false
                micButton.text = "🎤 اضغط للاتصال"
            } else {
                startVoiceRecognition()
            }
        }
    }
    
    // ==================== الأذونات ====================
    private fun hasPermissions(): Boolean {
        return arrayOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.RECORD_AUDIO
        ).all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }
    }
    
    private fun requestPermissionsMethod() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.RECORD_AUDIO
            ),
            100
        )
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == 100) {
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
                initSpeechRecognizer()
                updateStatus("✓ تم منح الأذونات")
            } else {
                updateStatus("❌ يجب السماح بالأذونات")
            }
        }
    }
    
    // ==================== التعرف الصوتي ====================
    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    updateStatus("🎤 يرجى التحدث...")
                }
                
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    updateStatus("⏳ جاري التحليل...")
                }
                
                override fun onError(error: Int) {
                    val message = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "لم يتم التعرف على الأمر"
                        SpeechRecognizer.ERROR_NETWORK -> "خطأ في الشبكة"
                        else -> "خطأ: $error"
                    }
                    updateStatus("❌ $message")
                }
                
                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    if (!matches.isNullOrEmpty()) {
                        val voiceText = matches[0].lowercase()
                        updateStatus("📝 قلت: $voiceText")
                        processCommand(voiceText)
                    }
                }
                
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            updateStatus("✓ جاهز للاستماع")
        } else {
            updateStatus("❌ التعرف الصوتي غير متاح")
        }
    }
    
    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, 
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
        }
        
        speechRecognizer.startListening(intent)
        isListening = true
        micButton.text = "🔴 جاري الاستماع..."
    }
    
    // ==================== معالجة الأوامر ====================
    private fun processCommand(voiceText: String) {
        val contactName = when {
            "اتصل" in voiceText && "ب" in voiceText -> {
                voiceText.substringAfter("ب").trim()
            }
            "اتصل" in voiceText && "على" in voiceText -> {
                voiceText.substringAfter("على").trim()
            }
            "call" in voiceText -> {
                voiceText.substringAfter("call").trim()
            }
            else -> voiceText
        }
        
        if (contactName.isNotEmpty()) {
            updateStatus("🔍 جاري البحث عن: $contactName")
            findContactAndCall(contactName)
        }
    }
    
    // ==================== البحث والاتصال ====================
    private fun findContactAndCall(name: String) {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        
        val cursor = contentResolver.query(uri, projection, null, null, null)
        
        cursor?.use {
            val nameIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            
            var foundPhone: String? = null
            var foundName: String? = null
            var bestMatch: Pair<String, String>? = null
            var bestDistance = Int.MAX_VALUE
            
            while (it.moveToNext()) {
                val contactName = it.getString(nameIndex)
                val phoneNumber = it.getString(numberIndex)
                    .replace(Regex("[^0-9+]"), "")
                
                if (contactName.contains(name, ignoreCase = true)) {
                    foundPhone = phoneNumber
                    foundName = contactName
                    break
                }
                
                val distance = levenshteinDistance(name.lowercase(), contactName.lowercase())
                if (distance < bestDistance) {
                    bestDistance = distance
                    bestMatch = Pair(contactName, phoneNumber)
                }
            }
            
            val phoneToCall = foundPhone ?: (if (bestDistance <= 3) bestMatch?.second else null)
            val nameToDisplay = foundName ?: (if (bestDistance <= 3) bestMatch?.first else null)
            
            if (phoneToCall != null && nameToDisplay != null) {
                updateStatus("✓ وجدت: $nameToDisplay\n📞 الاتصال...")
                makeCall(phoneToCall)
            } else {
                updateStatus("❌ لم أجد جهة اتصال باسم: $name")
            }
        } ?: run {
            updateStatus("❌ خطأ في الوصول لجهات الاتصال")
        }
    }
    
    private fun makeCall(phoneNumber: String) {
        try {
            val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phoneNumber"))
            startActivity(callIntent)
            Toast.makeText(this, "جاري الاتصال...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            updateStatus("❌ خطأ في الاتصال: ${e.message}")
        }
    }
    
    // ==================== دوال مساعدة ====================
    private fun levenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j
        
        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                dp[i][j] = when {
                    s1[i - 1] == s2[j - 1] -> dp[i - 1][j - 1]
                    else -> 1 + minOf(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1])
                }
            }
        }
        return dp[s1.length][s2.length]
    }
    
    private fun updateStatus(message: String) {
        runOnUiThread {
            statusText.text = message
        }
    }
    
    override fun onDestroy() {
        if (::speechRecognizer.isInitialized) {
            speechRecognizer.destroy()
        }
        super.onDestroy()
    }
}
