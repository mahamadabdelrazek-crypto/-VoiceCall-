# ProGuard rules for Voice Call App

-keep class com.example.freecall.** { *; }

# Keep AndroidX
-keep class androidx.** { *; }
-dontwarn androidx.**

# Keep Android classes
-keep class android.** { *; }
-dontwarn android.**

# Keep Kotlin
-keep class kotlin.** { *; }
-dontwarn kotlin.**

-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
